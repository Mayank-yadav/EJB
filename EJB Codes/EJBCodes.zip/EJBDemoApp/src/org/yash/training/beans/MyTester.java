package org.yash.training.beans;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;

/**
 * Session Bean implementation class MyTester
 */
@Singleton
@LocalBean
@Startup
public class MyTester {
	@EJB
	MyStatelessBeanLocal myBean;
	@PostConstruct
	public void myMain(){
		System.out.println(myBean.sayHello("Pankaj Sharma"));
	}

   

}
