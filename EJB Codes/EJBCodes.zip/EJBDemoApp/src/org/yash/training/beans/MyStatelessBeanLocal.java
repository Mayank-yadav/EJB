package org.yash.training.beans;

import javax.ejb.Local;

@Local
public interface MyStatelessBeanLocal {

		String sayHello(String name);
}
