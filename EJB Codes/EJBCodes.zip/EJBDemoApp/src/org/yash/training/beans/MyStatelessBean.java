package org.yash.training.beans;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class MyStatelessBean
 */
@Stateless
@LocalBean
public class MyStatelessBean implements MyStatelessBeanLocal {

    /**
     * Default constructor. 
     */
    public MyStatelessBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public String sayHello(String name) {		
		return "Hello "+name;
	}

}
