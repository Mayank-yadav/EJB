package com.yash.training.bean;

import javax.ejb.Local;

@Local
public interface UserServiceBeanLocal {

	public String userRegistration(String name);
	
}
