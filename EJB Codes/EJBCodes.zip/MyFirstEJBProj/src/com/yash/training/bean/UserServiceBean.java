package com.yash.training.bean;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class UserServiceBean
 */
@Stateless
@LocalBean
public class UserServiceBean implements UserServiceBeanLocal {

    /**
     * Default constructor. 
     */
    public UserServiceBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public String userRegistration(String name) {
		//TODO : put here your logic for registring the user
		return name+ " : you are registered successfully!";
	}

}
