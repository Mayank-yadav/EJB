package com.yash.training.bean;

import javax.ejb.ConcurrencyManagement;
import javax.ejb.ConcurrencyManagementType;
import javax.ejb.LocalBean;
import javax.ejb.Lock;
import javax.ejb.LockType;
import javax.ejb.Singleton;

/**
 * Session Bean implementation class MySingletonBean
 */
@Singleton
@LocalBean

public class MySingletonBean implements MySingletonBeanLocal {

	private int number;
	@Override
	public int getNumber() {
		
		return number;
	}
	@Override	
	public void increment() {
		number++;
	}

  
}
