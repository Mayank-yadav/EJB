package com.yash.training.bean;

import javax.ejb.Local;

@Local
public interface MySingletonBeanLocal {
	public void increment();
	
	public int getNumber();
}
