package com.yash.training.bean;

import javax.ejb.Local;

@Local
public interface MyStatelessSessionBeanLocal {
	
	String sayHello(String name);

}
