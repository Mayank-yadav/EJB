package com.yash.training.bean;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class MyStatelessSessionBean
 */
@Stateless
@LocalBean
public class MyStatelessSessionBean implements MyStatelessSessionBeanLocal {
	

    /**
     * Default constructor. 
     */
    public MyStatelessSessionBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public String sayHello(String name) {
		return "Hello : "+name;
		
	}
	@PostConstruct
	public void init(){
		System.out.println("I am initializing....");
	}
	@PreDestroy
	//clean up method
	//shutdown hook
	public void destroy(){
		System.out.println("I am detroyed..");
	}

}
