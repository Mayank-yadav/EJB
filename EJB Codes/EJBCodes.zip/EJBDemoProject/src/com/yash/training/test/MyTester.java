package com.yash.training.test;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;

import com.yash.training.bean.MyStatelessSessionBeanLocal;

/**
 * Session Bean implementation class MyTester
 */
@Singleton
@LocalBean
// @startup will create the object of MyTester at the time of app deployment
// startup hook
@Startup 
public class MyTester {
	@EJB
	MyStatelessSessionBeanLocal myBean;
	@PostConstruct	
	public void myMain(){
		System.out.println(myBean.sayHello("Pankaj Sharma"));
	}

}
