package com.yash.training.bean;

import javax.ejb.Local;

@Local
public interface MyStatefullSessionBeanLocal {
	
	void setEmployeeId(int id);
	void setEmployeeName(String name);
	void finish();
	public void endSessionBean();

}
