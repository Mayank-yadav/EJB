package com.yash.training.bean;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.Remove;
import javax.ejb.Stateful;

import com.yash.training.pojo.Employee;

@Stateful
@LocalBean
public class MyStatefullSessionBean implements MyStatefullSessionBeanLocal {

	//state
	private int id;
	private String name;
	@Override
	public void setEmployeeId(int id) {
		
		this.id=id;
		
	}

	@Override
	public void setEmployeeName(String name) {
		
		this.name=name;
	}

	@Override	
	
	public void finish() {
		Employee emp=new Employee();
		emp.setId(id);
		emp.setName(name);
		System.out.println(emp.getId());
		System.out.println(emp.getName());		
	}

	@Remove
	public void endSessionBean(){
		
	}

}
