package com.yash.training.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.training.beans.MySessionBean;
import com.yash.training.beans.MySessionBeanLocal;
import com.yash.training.pojo.Employee;
@WebServlet("/TestEJBServlet")
public class TestEJBServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@EJB
	MySessionBeanLocal myBean;
       
   @Override
protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	  
	   PrintWriter out=response.getWriter();
	   out.println(myBean.sayHello("Pankaj Sharma<br/>"));
	   List<Employee> employees=myBean.getAllEmployeeList();
	   for (Employee employee : employees) {
		   out.println(employee.getName()+"<br/>");
		
	}
}

}
