package com.yash.training.beans;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import com.yash.training.pojo.Employee;

/**
 * Session Bean implementation class MySessionBean
 */
@Stateless
@LocalBean
public class MySessionBean implements MySessionBeanLocal {

	public MySessionBean() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String sayHello(String name) {
		return "Hello : "+name;
	}
	@Override
	public List<Employee> getAllEmployeeList() {
		List<Employee> employeeList=new ArrayList<Employee>();
		employeeList.add(new Employee("Pankaj Sharma"));
		employeeList.add(new Employee("Dinesh"));
		employeeList.add(new Employee("Rakesh"));
		employeeList.add(new Employee("Deepesh"));
		return employeeList;
	}
	@PostConstruct
	public void init(){
		System.out.println("inside init.....");
	}
	
	@PreDestroy
	public void destroy(){
		System.out.println("inside destroy.....");
	}
	
	

}
