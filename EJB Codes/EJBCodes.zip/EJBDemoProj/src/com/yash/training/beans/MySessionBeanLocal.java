package com.yash.training.beans;

import java.util.List;

import javax.ejb.Local;

import com.yash.training.pojo.Employee;

@Local
public interface MySessionBeanLocal {
	
	public String sayHello(String name);
	public List<Employee> getAllEmployeeList();
	

}
